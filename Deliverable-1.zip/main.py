def generate_cipher_key():
  key = {'a': 'c', 'b': 'd', 'c': 'e', 'd': 'f', 'e': 'g',
         'f': 'h', 'g': 'i', 'h': 'j', 'i': 'k', 'j': 'l',
         'k': 'm', 'l': 'n', 'm': 'o', 'n': 'p', 'o': 'q',
         'p': 'r', 'q': 's', 'r': 't', 's': 'u', 't': 'v',
         'u': 'w', 'v': 'x', 'w': 'y', 'x': 'z', 'y': 'a',
         'z': 'b'}

  return key

def encrypt_message(message, key):
  encrypted_message = ""
  for char in message:
      if char.lower() in key:
          encrypted_message += key[char.lower()]
      else:
          encrypted_message += char

  return encrypted_message

key = generate_cipher_key()
plaintext = "Hello"
encrypted = encrypt_message(plaintext, key)

print("Alice:", plaintext)
print("Bob:", encrypted)